<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Partiner;
use Faker\Generator as Faker;

$factory->define(Partiner::class, function (Faker $faker) {
    return [
        //
    ];
});
