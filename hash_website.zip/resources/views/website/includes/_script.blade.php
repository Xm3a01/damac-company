
<!-- Vendor JS Files -->
{{-- <script src="{{ asset('/js/app.js') }}" defer></script> --}}
<script src="{{ asset('assets/assets/vendor/aos/aos.js') }}"></script>
<script src="{{ asset('assets/assets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('assets/assets/vendor/glightbox/js/glightbox.min.js') }}"></script>
<script src="{{ asset('assets/assets/vendor/isotope-layout/isotope.pkgd.min.js') }}"></script>
<script src="{{ asset('assets/assets/vendor/php-email-form/validate.js') }}"></script>
<script src="{{ asset('assets/assets/vendor/swiper/swiper-bundle.min.js') }}"></script>
<script src="{{ asset('assets/assets/vendor/waypoints/noframework.waypoints.js') }}"></script>
<script src="{{ asset('assets/assets/js/main.js') }}"></script>
