
{{-- <link href="{{ asset('/css/app.css') }}" rel="stylesheet" /> --}}
<link href="{{ asset('assets/assets/vendor/animate.css/animate.min.css') }}" rel="stylesheet">
<link href="{{ asset('assets/assets/vendor/aos/aos.css" rel="stylesheet') }}">
<link href="{{ asset('assets/assets/vendor/bootstrap/css/bootstrap.rtl.min.css') }}" rel="stylesheet">
<link href="{{ asset('assets/assets/vendor/bootstrap-icons/bootstrap-icons.css') }}" rel="stylesheet">
<link href="{{ asset('assets/assets/vendor/boxicons/css/boxicons.min.css') }}" rel="stylesheet">
<link href="{{ asset('assets/assets/vendor/glightbox/css/glightbox.min.css') }}" rel="stylesheet">
<link href="{{ asset('assets/assets/vendor/remixicon/remixicon.css') }}" rel="stylesheet">
<link href="{{ asset('assets/assets/vendor/swiper/swiper-bundle.min.css') }}" rel="stylesheet">
<link href="{{ asset('assets/assets/css/style.css') }}" rel="stylesheet">
<link href="{{ asset('assets/assets/css/rtl.css') }}" rel="stylesheet">
<link href="{{ asset('assets/assets/css/main.css') }}" rel="stylesheet">
