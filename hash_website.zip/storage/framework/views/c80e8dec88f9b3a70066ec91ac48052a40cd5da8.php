
<!-- Vendor CSS Files -->
<link href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/icofont/icofont.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/remixicon/remixicon.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/venobox/venobox.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/owl.carousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/aos/aos.css')); ?>" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet"><?php /**PATH C:\Projects\hash_website\resources\views/website/includes/_style.blade.php ENDPATH**/ ?>