

<?php $__env->startSection('content'); ?>

    <td class="text-center">
        <a  href="<?php echo e(route('portfolios.create')); ?>" class="btn btn-round btn-primary">Add portfolio</a>
    </td>

    <div class="card">
        <div class="card-header">
            <h4 class="card-title"> All Events</h4>
        </div>
        <div class="card-body custom-table">
            <div class="table">
                <table class="table">
                    <thead class=" text-primary">
                        <tr>
                            
                            <th>Name</th>
                            <th>Action </th>
                          
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($portfolio->getMedia('portfolio')); ?>

                        <tr>
                            <td><img src="<?php echo e($portfolio->getFirstMediaUrl('portfolios')); ?>" alt="" height="40" width="40" class="rounded-full"></td>
                            <td><?php echo e($portfolio->name); ?></td>
                            <td>
                                <form action="<?php echo e(route('portfolios.destroy' , $portfolio->id)); ?>" method="post">  
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a  href="<?php echo e(route('portfolios.edit' , $portfolio->id)); ?>" class="btn btn-round btn-primary"><i
                                            class="nc-icon nc-settings"></i></a>
    
                                    <button   type="submit" class="btn btn-round btn-danger"><i
                                            class="nc-icon nc-simple-remove"></i></button>
                                </form>
                            </td>
                        </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
                <?php echo e($portfolios->links()); ?>

            </div>
        </div>


    </div>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\hash_website\resources\views/admins/dashboard/portfolios/index.blade.php ENDPATH**/ ?>