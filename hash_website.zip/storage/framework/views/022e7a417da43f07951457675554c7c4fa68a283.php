

<?php $__env->startSection('content'); ?>

    <div class="col-md-8">
        <div class="card card-user">
            <div class="card-header">
                <h5 class="card-title">edit Employee</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('teams.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-12 pr-1">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" class="form-control" placeholder="Name" name="name">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 pl-3">
                            <div class="form-group">
                                <label for="">Job title</label>
                                <input type="text" class="form-control" placeholder="Job title" name="job_title">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 pl-3">
                            <div class="form-group">
                                <label for="">Upload Image <button class="btn btn-primary">attche</button></label>
                                <input type="file" class="form-control" placeholder="File" name="image">
                            </div>
                        </div>
                    </div>
                    <div class="row">

                        <div class="col-md-12 pl-3">

                            <div class="form-group">
                                <label>Description</label>
                                <textarea class="form-control textarea" name="description"></textarea>
                            </div>
                        </div>
                    </div>

                    <h4>Meida Links</h4>
                    <hr>

                    <div class="mediaForm">
                    <?php $__currentLoopData = $mediaTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <div class="row">
                        <div class="col-md-4 pl-3">
                            <div class="form-group row">
                                <input type="checkbox" <?php echo e($i == 0 ? 'checked hidden' : ''); ?> class="form-control col-md-4" id="media_<?php echo e($i); ?>" onchange="event.preventDefault(); x(this.id , <?php echo e($i); ?>)" id=""> 
                                <label for="twitter" class="col-md-8"><?php echo e($type); ?></label>
                            </div>
                        </div>

                        <div class="col-md-8 pl-5">
                            <div class="form-group" id="url_<?php echo e($i); ?>" style="display: none">
                                <input type="text" value="<?php echo e($i == 0 ? 'value' : ''); ?>" name="link[]" id="" class="form-control" placeholder="Media Url"> 
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="row">
                        <div class="update ml-auto mr-auto">
                            <button type="submit" class="btn btn-primary btn-round">Add</button>
                        </div>
                    </div>
                </form>
            </div>
        </div> 
    </div>


   
<?php $__env->stopSection(); ?>


<script>
    function x(id , i){
        if(id == 'media_'+i) {
            checkbox = document.getElementById('media_'+i);
            if(checkbox.checked)
              item = document.getElementById('url_'+i).style.display = "inline";
            else 
              item = document.getElementById('url_'+i).style.display = "none";
        }
    }
    </script>



<?php echo $__env->make('admins.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\hash_website\resources\views/admins/dashboard/teams/create.blade.php ENDPATH**/ ?>