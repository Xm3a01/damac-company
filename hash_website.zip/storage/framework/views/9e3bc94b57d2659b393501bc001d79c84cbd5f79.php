

<?php $__env->startSection('content'); ?>

    <div class="col-md-8">
        <div class="card card-user">
            <div class="card-header">
                <h5 class="card-title">Add Service</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('services.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-12 pr-1">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" class="form-control" placeholder="Name" name="name">
                            </div>
                        </div>

                        <div class="col-md-12 pr-1">
                            <div class="form-group">
                                <label>Target/Companies</label>
                                <input type="text" class="form-control" placeholder="Target/Companies" name="target">
                            </div>
                        </div>

                        <div class="col-md-12 pr-1">
                            <div class="form-group">
                                <label style="color: blue; mouse:pointer">Attache Images</label>
                                <input type="file" class="form-control-file" placeholder="Traget/Companies" name="images[]" multiple>
                            </div>
                        </div>

                    </div>

                    <div class="row">

                        <div class="col-md-12 pl-3">

                            <div class="form-group">
                                <label>Description</label>
                                <textarea class="form-control textarea" name="description"></textarea>
                            </div>
                        </div>
                    </div>

                    <h4>Show</h4>
                    <hr>

                    <div class="mediaForm">
                    
                    <div class="row">
                        <div class="col-md-12 pl-3">
                            <div class="form-group">
                                <label for="twitter" class="col-md-8">Service icon</label>
                                <select name="icon" id="" class="form-control">
                                    <?php $__currentLoopData = $serviceType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>         
                                      <option value="<?php echo e($index == 0 ? '': $index); ?>"><?php echo e($service); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    

                            
                        </div>
                    <div class="row">
                        <div class="update ml-auto mr-auto">
                            <button type="submit" class="btn btn-primary btn-round">Add</button>
                        </div>
                    </div>
                </form>
            </div>
        </div> 
    </div>


   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<script>
    function x(id , i){
        if(id == 'media_'+i) {
            checkbox = document.getElementById('media_'+i);
            if(checkbox.checked)
              item = document.getElementById('url_'+i).style.display = "inline";
            else 
              item = document.getElementById('url_'+i).style.display = "none";
        }
    }

</script>


<?php echo $__env->make('admins.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\hash_website\resources\views/admins/dashboard/services/create.blade.php ENDPATH**/ ?>