

<?php $__env->startSection('content'); ?>

    <td class="text-center">
        <a href="<?php echo e(route('services.create')); ?>" class="btn btn-round btn-primary">Add Service</a>
    </td>
    <td class="text-center">
        <a href="<?php echo e(route('partiners.create')); ?>" class="btn btn-round btn-primary">Add Partiner</a>
    </td>
    <td class="text-center">
        <a href="<?php echo e(route('statstics.create')); ?>" class="btn btn-round btn-primary">Add Skill</a>
    </td>
    <td class="text-center">
        <a href="<?php echo e(route('teams.create')); ?>" class="btn btn-round btn-primary">Add Team</a>
    </td>
    <td class="text-center">
        <a href="<?php echo e(route('portfolios.create')); ?>" class="btn btn-round btn-primary">Add Portfolio</a>
    </td>
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Company</h4>
        </div>
        <div class="card-body custom-table">
            <div class="table">
                <table class="table">
                    <thead class=" text-primary">
                        <tr>
                            <th>image</th>
                            <th>name</th>
                            <th>about</th>
                            <th>Why us</th>
                            <th>actions</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php if(!is_null($company)): ?>
                            
                        <tr>
                            <td> <img src="<?php echo e($company->image ? $company->image  : asset('assets/images/noImage.png')); ?>" alt="Image" height="45" width="45"></td>
                            <td><?php echo e($company->name); ?></td>
                            <td><?php echo e(Str::limit($company->about, 40)); ?></td>
                            <td><?php echo e(Str::limit($company->why_us, 40)); ?></td>

                            <td>
                                

                                    <a title="Edit" href="<?php echo e(route('companies.edit', $company->id)); ?>"
                                        class="btn btn-round btn-primary"><i class="nc-icon nc-settings"></i></a>
                                    
                                

                            </td>
                        </tr>
                        <?php else: ?>
                        <td class="text-center">
                            <a href="<?php echo e(route('companies.create')); ?>" class="btn btn-round btn-primary">Add company</a>
                        </td>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\hash_website\resources\views/admins/dashboard/companies/index.blade.php ENDPATH**/ ?>