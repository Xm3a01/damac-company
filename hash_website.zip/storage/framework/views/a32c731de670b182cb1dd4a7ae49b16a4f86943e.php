

<?php $__env->startSection('content'); ?>
    <td class="text-center">
        <a  href="<?php echo e(route('partiners.create')); ?>" class="btn btn-round btn-primary">Add Partiner</a>
    </td>

    <div class="card">
        <div class="card-header">
            <h4 class="card-title"> All Partiner</h4>
        </div>
        <div class="card-body custom-table">
            <div class="table">
                <table class="table">
                    <thead class=" text-primary">
                        <tr>
                            <th>Logo</th>
                            <th>Name</th>
                            <th>Action </th>
                          
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $partiners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partiner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><img src="<?php echo e($partiner->image ? $partiner->image  : asset('assets/images/noImage.png')); ?>" alt="Image" height="45" width="45"></td>
                            <td><?php echo e($partiner->name); ?></td>
                            <td>
                                <form action="<?php echo e(route('partiners.destroy' , $partiner->id)); ?>" method="post">  
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a  href="<?php echo e(route('partiners.edit' , $partiner->id)); ?>" class="btn btn-round btn-primary"><i
                                            class="nc-icon nc-settings"></i></a>
    
                                    <button   type="submit" class="btn btn-round btn-danger"><i
                                            class="nc-icon nc-simple-remove"></i></button>
                                </form>
                            </td>
                        </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
                
            </div>
        </div>


    </div>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\hash_website\resources\views/admins/dashboard/partiners/index.blade.php ENDPATH**/ ?>