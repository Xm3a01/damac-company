<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Hash developed Projects</title>
    <?php echo $__env->make('_include.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body style="background-color: #f4f3ef;">
   <div class="container">
    <div class="wrapper ">
     <div class="main-panel">

      <div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div>

    </div>
   </div>
 </div>

  <?php echo $__env->make('_include.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('_include.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html><?php /**PATH C:\Projects\hash_website\resources\views/app.blade.php ENDPATH**/ ?>