

<?php $__env->startSection('content'); ?>

    <td class="text-center">
        <a  href="<?php echo e(route('services.create')); ?>" class="btn btn-round btn-primary">Add Service</a>
    </td>

    <div class="card">
        <div class="card-header">
            <h4 class="card-title"> All Events</h4>
        </div>
        <div class="card-body custom-table">
            <div class="table">
                <table class="table">
                    <thead class=" text-primary">
                        <tr>
                            
                            <th>Name</th>
                            <th>description</th>
                            <th>Action </th>
                          
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            
                            <td><?php echo e($service->name); ?></td>
                            <td><?php echo e(Str::limit($service->description , 80 , '')); ?></td>
                            <td>
                                <form action="<?php echo e(route('services.destroy' , $service->id)); ?>" method="post">  
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a  href="<?php echo e(route('services.edit' , $service->id)); ?>" class="btn btn-round btn-primary"><i
                                            class="nc-icon nc-settings"></i></a>
    
                                    <button   type="submit" class="btn btn-round btn-danger"><i
                                            class="nc-icon nc-simple-remove"></i></button>
                                </form>
                            </td>
                        </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
                <?php echo e($services->links()); ?>

            </div>
        </div>


    </div>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\hash_website\resources\views/admins/dashboard/services/index.blade.php ENDPATH**/ ?>