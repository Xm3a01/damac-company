
<!-- Vendor JS Files -->

<script src="<?php echo e(asset('assets/assets/vendor/aos/aos.js')); ?>"></script>
<script src="<?php echo e(asset('assets/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/assets/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/assets/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/assets/vendor/php-email-form/validate.js')); ?>"></script>
<script src="<?php echo e(asset('assets/assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/assets/vendor/waypoints/noframework.waypoints.js')); ?>"></script>
<script src="<?php echo e(asset('assets/assets/js/main.js')); ?>"></script>
<?php /**PATH D:\Projects\hash_website\resources\views/website/includes/_script.blade.php ENDPATH**/ ?>