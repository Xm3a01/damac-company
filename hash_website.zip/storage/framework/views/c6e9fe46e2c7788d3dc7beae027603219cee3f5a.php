
<!DOCTYPE html>
<html lang="en">

<head>
  <?php echo $__env->make('admins.dashboard._includes.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="" style="background-color: #f4f3ef;">
  <div class="wrapper ">

    <?php echo $__env->make('admins.dashboard._includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>              

    <div class="main-panel">
      <!-- Navbar -->
    <?php echo $__env->make('admins.dashboard._includes.navbar' , ['title' => $title ?? "Dashboard"] , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
      <!-- End Navbar -->
      <div class="content">

        <?php echo $__env->yieldContent('content'); ?>
     
    </div>
  </div>
  <!--   Core JS Files   -->
  <?php echo $__env->make('admins.dashboard._includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('admins.dashboard._includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\Projects\hash_website\resources\views/admins/dashboard/master.blade.php ENDPATH**/ ?>