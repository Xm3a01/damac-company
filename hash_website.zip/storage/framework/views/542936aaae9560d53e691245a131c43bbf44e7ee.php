

<?php $__env->startSection('content'); ?>


    <div class="card">
        <div class="card-header">
            <h4 class="card-title"> Profile</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 offset-4 form-group">Name : <?php echo e($user->name); ?></div>
                <div class="col-md-4 offset-4 form-group">Email : <?php echo e($user->email); ?></div>
                <div class="col-md-4 offset-4 form-group">Password : ********</div>
            </div>
        </div>

        <a href="<?php echo e(route('profile.show')); ?>" class="btn btn-info">Edit</a>

    </div>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\hash_website\resources\views/admins/dashboard/profile/index.blade.php ENDPATH**/ ?>