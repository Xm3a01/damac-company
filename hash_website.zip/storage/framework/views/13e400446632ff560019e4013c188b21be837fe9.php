

<?php $__env->startSection('content'); ?>

    <td class="text-center">
        <a  href="<?php echo e(route('statstics.create')); ?>" class="btn btn-round btn-primary">Add Skill</a>
    </td>

    <div class="card">
        <div class="card-header">
            <h4 class="card-title"> All galleries</h4>
        </div>
        <div class="card-body custom-table">
            <div class="table">
                <table class="table">
                    <thead class=" text-primary">
                        <tr>
                            <th>name</th>
                            <th>persent</th>
                            <th>Action </th>
                          
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($skill->name); ?></td>
                            <td><?php echo e($skill->percent); ?>%</td>
                            <td>
                                <form action="<?php echo e(route('statstics.destroy' , $skill->id)); ?>" method="post">  
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a  href="<?php echo e(route('statstics.edit' , $skill->id)); ?>" class="btn btn-round btn-primary"><i
                                            class="nc-icon nc-settings"></i></a>
    
                                    <button   type="submit" class="btn btn-round btn-danger"><i
                                            class="nc-icon nc-simple-remove"></i></button>
                                </form>

                            </td>
                        </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
                
            </div>
        </div>


    </div>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\hash_website\resources\views/admins/dashboard/skills/index.blade.php ENDPATH**/ ?>