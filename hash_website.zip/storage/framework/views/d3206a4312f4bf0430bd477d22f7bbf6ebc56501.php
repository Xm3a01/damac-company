<div class="sidebar" data-color="white" data-active-color="danger">
    <div class="logo">
        <a href="/dashboard" class="simple-text logo-small">
         <div class="logo-image-big">
          
           Damac
        </div>
        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class=" <?php echo e(request()->is('dashboard') ? 'active' : ''); ?> ">
                <a href="/dashboard">
                    <i class="nc-icon nc-bank"></i>
                    <p>Home</p>
                </a>
            </li>

            <li class="<?php echo e(request()->is('*companies*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('companies.create')); ?>">
                    <i class="nc-icon nc-bell-55"></i>
                    <p>Companies</p>
                </a>
            </li>

            <li class="<?php echo e(request()->is('*services*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('services.index')); ?>">
                    <i class="nc-icon nc-caps-small"></i>
                    <p>Services</p>
                </a>
            </li>
            
            <li class="<?php echo e(request()->is('*portfolios*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('portfolios.index')); ?>">
                    <i class="nc-icon nc-caps-small"></i>
                    <p>Portfolios</p>
                </a>
            </li>

            <li class="<?php echo e(request()->is('*partiners*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('partiners.index')); ?>">
                    <i class="nc-icon nc-caps-small"></i>
                    <p>Partiners</p>
                </a>
            </li>

            

            
             
            
        </ul>
    </div>
</div>

<style>
    .sidebar[data-active-color="danger"] .nav li.active>a,
    .sidebar[data-active-color="danger"] .nav li.active>a i,
    .sidebar[data-active-color="danger"] .nav li.active>a[data-toggle="collapse"],
    .sidebar[data-active-color="danger"] .nav li.active>a[data-toggle="collapse"] i,
    .sidebar[data-active-color="danger"] .nav li.active>a[data-toggle="collapse"]~div>ul>li.active .sidebar-mini-icon,
    .sidebar[data-active-color="danger"] .nav li.active>a[data-toggle="collapse"]~div>ul>li.active>a,
    .off-canvas-sidebar[data-active-color="danger"] .nav li.active>a,
    .off-canvas-sidebar[data-active-color="danger"] .nav li.active>a i,
    .off-canvas-sidebar[data-active-color="danger"] .nav li.active>a[data-toggle="collapse"],
    .off-canvas-sidebar[data-active-color="danger"] .nav li.active>a[data-toggle="collapse"] i,
    .off-canvas-sidebar[data-active-color="danger"] .nav li.active>a[data-toggle="collapse"]~div>ul>li.active .sidebar-mini-icon,
    .off-canvas-sidebar[data-active-color="danger"] .nav li.active>a[data-toggle="collapse"]~div>ul>li.active>a {
        color: #51cbce;
        opacity: 1;
    }

</style>
<?php /**PATH D:\Projects\hash_website\resources\views/admins/dashboard/_includes/sidebar.blade.php ENDPATH**/ ?>