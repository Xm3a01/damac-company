<?php $__env->startSection('content'); ?>
    <div class="col-md-8">
        <div class="card card-user">
            <div class="card-header">
                <h5 class="card-title">Company Info</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('companies.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-12 p-2">
                            <div class="form-group">
                                <label>About</label>
                                <textarea rows="10" class="form-control" placeholder="About" name="about"><?php echo e($company->about ?? ""); ?></textarea>
                            </div>
                        </div>
                        <div class="col-md-12 p-2">
                            <div class="form-group">
                                <label>Vission</label>
                                <textarea rows="10" class="form-control" placeholder="Vission" name="vission"><?php echo e($company->vission ?? ""); ?></textarea>
                            </div>
                        </div>
                        <div class="col-md-12 p-2">
                            <div class="form-group">
                                <label>Goal</label>
                                <textarea rows="10" class="form-control" placeholder="Goal" name="goal"><?php echo e($company->goal ?? ""); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="update ml-auto mr-auto">
                            <button type="submit" class="btn btn-primary btn-round">create</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\hash_website\resources\views/admins/dashboard/companies/create.blade.php ENDPATH**/ ?>